
This is a collection of software packages for the Steam Linux Runtime.

Each individual package has its own licensing terms, typically in:
    usr/share/doc/<package>/copyright.

The scripts used to build these packages can be found on GitHub:
https://github.com/ValveSoftware/steam-runtime

The source code and debug versions of the packages can be found here:
https://repo.steampowered.com/steamrt-images-scout/snapshots/


The scripts and other documentation contributed by Valve are covered under
the following copyright notice:

Copyright (C) 2013 Valve Corporation

Permission is hereby granted, free of charge, to any person obtaining a copy of these scripts and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
